<?php

require_once dirname(__FILE__). '/../autoload.php';
require_once __DIR__ . '/TestConfig.php';
